class MissionCompleteUIPrefabType:
    None_ = 0
    UIStageSelect = 1
    UIAcademyLobby = 2
    UIArena = 3
    UIRaidLobby = 4
    UICafe = 5
    UIShop = 6
    UIGacha = 7
    UIScenarioMode = 8
    UICharacterCollection = 9
    UIWeekDungeonLobby = 10
    UISchoolDungeonLobby = 11
    UIMultiFloorRaid_Lobby = 12
    UIWeekDungeonLobby_Chaser = 13
    UIEliminateRaidLobby = 14
