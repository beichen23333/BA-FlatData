class ProductDisplayTag:
    None_ = 0
    New = 1
    Hot = 2
    Sale = 3
    Limited = 4
    Free = 5
    Recommend = 6
