class ItemCategory:
    Coin = 0
    CharacterExpGrowth = 1
    SecretStone = 2
    Material = 3
    Consumable = 4
    Collectible = 5
    Favor = 6
    RecruitCoin = 7
    InvisibleToken = 8
    BattlePass = 9
    ProductSelect = 10
    ProductDailyRecord = 11
    ProductStreakRecord = 12
