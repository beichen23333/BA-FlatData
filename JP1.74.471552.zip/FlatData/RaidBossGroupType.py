class RaidBossGroupType:
    None_ = 0
    Binah = 1
    Chesed = 2
    ShiroKuro = 3
    Hieronymus = 4
    Kaitenger = 5
    Perorozilla = 6
    HOD = 7
    Goz = 8
    HoverCraft = 9
    EN0005 = 10
    EN0006 = 11
    EN0010 = 12
    EN0013 = 13
    EN0022 = 14
    EN0023 = 15
