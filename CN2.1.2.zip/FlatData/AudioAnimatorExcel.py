
import flatbuffers
from flatbuffers.compat import import_numpy
np = import_numpy()

class AudioAnimatorExcel:
    __slots__ = ['_tab']

    @classmethod
    def GetRootAs(cls, buf, offset=0):
        n = flatbuffers.encode.Get(flatbuffers.packer.uoffset, buf, offset)
        x = AudioAnimatorExcel()
        x.Init(buf, n + offset)
        return x

    def Init(self, buf, pos):
        self._tab = flatbuffers.table.Table(buf, pos)


    def ControllerNameHash(self):
        o = flatbuffers.number_types.UOffsetTFlags.py_type(self._tab.Offset(4))
        if o != 0:
            return self._tab.Get(flatbuffers.number_types.Uint32Flags, o + self._tab.Pos)
        return 0


    def VoiceNamePrefix(self):
        o = flatbuffers.number_types.UOffsetTFlags.py_type(self._tab.Offset(6))
        if o != 0:
            return self._tab.String(o + self._tab.Pos)
        return None


    def StateNameHash(self):
        o = flatbuffers.number_types.UOffsetTFlags.py_type(self._tab.Offset(8))
        if o != 0:
            return self._tab.Get(flatbuffers.number_types.Uint32Flags, o + self._tab.Pos)
        return 0


    def StateName(self):
        o = flatbuffers.number_types.UOffsetTFlags.py_type(self._tab.Offset(10))
        if o != 0:
            return self._tab.String(o + self._tab.Pos)
        return None


    def IgnoreInterruptDelay(self):
        o = flatbuffers.number_types.UOffsetTFlags.py_type(self._tab.Offset(12))
        if o != 0:
            return self._tab.Get(flatbuffers.number_types.BoolFlags, o + self._tab.Pos)
        return 0


    def IgnoreInterruptPlay(self):
        o = flatbuffers.number_types.UOffsetTFlags.py_type(self._tab.Offset(14))
        if o != 0:
            return self._tab.Get(flatbuffers.number_types.BoolFlags, o + self._tab.Pos)
        return 0


    def Volume(self):
        o = flatbuffers.number_types.UOffsetTFlags.py_type(self._tab.Offset(16))
        if o != 0:
            return self._tab.Get(flatbuffers.number_types.Float32Flags, o + self._tab.Pos)
        return 0


    def Delay(self):
        o = flatbuffers.number_types.UOffsetTFlags.py_type(self._tab.Offset(18))
        if o != 0:
            return self._tab.Get(flatbuffers.number_types.Float32Flags, o + self._tab.Pos)
        return 0


    def RandomPitchMin(self):
        o = flatbuffers.number_types.UOffsetTFlags.py_type(self._tab.Offset(20))
        if o != 0:
            return self._tab.Get(flatbuffers.number_types.Int32Flags, o + self._tab.Pos)
        return 0


    def RandomPitchMax(self):
        o = flatbuffers.number_types.UOffsetTFlags.py_type(self._tab.Offset(22))
        if o != 0:
            return self._tab.Get(flatbuffers.number_types.Int32Flags, o + self._tab.Pos)
        return 0


    def AudioPriority(self):
        o = flatbuffers.number_types.UOffsetTFlags.py_type(self._tab.Offset(24))
        if o != 0:
            return self._tab.Get(flatbuffers.number_types.Int32Flags, o + self._tab.Pos)
        return 0


    def AudioClipPathLength(self):
        o = flatbuffers.number_types.UOffsetTFlags.py_type(self._tab.Offset(26))
        if o != 0:
            return self._tab.Get(flatbuffers.number_types.Int32Flags, o + self._tab.Pos)
        return 0


    def VoiceHashLength(self):
        o = flatbuffers.number_types.UOffsetTFlags.py_type(self._tab.Offset(28))
        if o != 0:
            return self._tab.Get(flatbuffers.number_types.Int32Flags, o + self._tab.Pos)
        return 0




    @staticmethod
    def Start(builder): builder.StartObject(13)
    @staticmethod
    def End(builder): return builder.EndObject()


    @staticmethod
    def AddControllerNameHash(builder, ControllerNameHash): builder.PrependUint32Slot(0, ControllerNameHash, 0)


    @staticmethod
    def AddVoiceNamePrefix(builder, VoiceNamePrefix): builder.PrependUOffsetTRelativeSlot(1, flatbuffers.number_types.UOffsetTFlags.py_type(VoiceNamePrefix), 0)

    @staticmethod
    def AddStateNameHash(builder, StateNameHash): builder.PrependUint32Slot(2, StateNameHash, 0)


    @staticmethod
    def AddStateName(builder, StateName): builder.PrependUOffsetTRelativeSlot(3, flatbuffers.number_types.UOffsetTFlags.py_type(StateName), 0)

    @staticmethod
    def AddIgnoreInterruptDelay(builder, IgnoreInterruptDelay): builder.PrependBoolSlot(4, IgnoreInterruptDelay, 0)


    @staticmethod
    def AddIgnoreInterruptPlay(builder, IgnoreInterruptPlay): builder.PrependBoolSlot(5, IgnoreInterruptPlay, 0)


    @staticmethod
    def AddVolume(builder, Volume): builder.PrependFloat32Slot(6, Volume, 0)


    @staticmethod
    def AddDelay(builder, Delay): builder.PrependFloat32Slot(7, Delay, 0)


    @staticmethod
    def AddRandomPitchMin(builder, RandomPitchMin): builder.PrependInt32Slot(8, RandomPitchMin, 0)


    @staticmethod
    def AddRandomPitchMax(builder, RandomPitchMax): builder.PrependInt32Slot(9, RandomPitchMax, 0)


    @staticmethod
    def AddAudioPriority(builder, AudioPriority): builder.PrependInt32Slot(10, AudioPriority, 0)


    @staticmethod
    def AddAudioClipPathLength(builder, AudioClipPathLength): builder.PrependInt32Slot(11, AudioClipPathLength, 0)


    @staticmethod
    def AddVoiceHashLength(builder, VoiceHashLength): builder.PrependInt32Slot(12, VoiceHashLength, 0)

