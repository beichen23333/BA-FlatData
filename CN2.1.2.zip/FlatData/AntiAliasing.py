class AntiAliasing:
    Off = 0
    Low = 1
    High = 2
