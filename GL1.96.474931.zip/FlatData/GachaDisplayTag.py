class GachaDisplayTag:
    None_ = 0
    Limited = 1
    TwoStar = 2
    ThreeStar = 3
    Free = 4
    New = 5
    Fes = 6
    SelectRecruit = 7
    LimitedThreeStar = 8
    Revival = 9
    SelectLimited = 10
    NewbieDateLimited = 11
    Unowned = 12
    SelectRecruitNotForSale = 13
