class DisplayGroupType:
    None_ = 0
    Default = 1
    Formation = 2
    Battle = 3
    Scenario = 4
    Momotalk = 5
    Cafe = 6
    Field = 7
    MinigameUndercover = 8
    MinigameShooting = 9
    MinigameRoad = 10
    MinigameCCG = 11
    MinigameJanken = 12
