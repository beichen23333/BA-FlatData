class ConcentrationVoiceCondition:
    None_ = 0
    PairMatchFail = 1
    PairMatchSuccess = 2
    RoundRenewal = 3
