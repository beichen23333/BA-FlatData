class CollisionDetectionMode:
    Discrete = 0
    Continuous = 1
    ContinuousDynamic = 2
    ContinuousSpeculative = 3
