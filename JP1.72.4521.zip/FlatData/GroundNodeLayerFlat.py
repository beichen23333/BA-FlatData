
import flatbuffers
from flatbuffers.compat import import_numpy
np = import_numpy()

class GroundNodeLayerFlat:
    __slots__ = ['_tab']

    @classmethod
    def GetRootAs(cls, buf, offset=0):
        n = flatbuffers.encode.Get(flatbuffers.packer.uoffset, buf, offset)
        x = GroundNodeLayerFlat()
        x.Init(buf, n + offset)
        return x

    def Init(self, buf, pos):
        self._tab = flatbuffers.table.Table(buf, pos)


    def LayersLength(self):
        o = flatbuffers.number_types.UOffsetTFlags.py_type(self._tab.Offset(4))
        if o != 0:
            return self._tab.Get(flatbuffers.number_types.Int32Flags, o + self._tab.Pos)
        return 0




    @staticmethod
    def Start(builder): builder.StartObject(1)
    @staticmethod
    def End(builder): return builder.EndObject()


    @staticmethod
    def AddLayersLength(builder, LayersLength): builder.PrependInt32Slot(0, LayersLength, 0)

