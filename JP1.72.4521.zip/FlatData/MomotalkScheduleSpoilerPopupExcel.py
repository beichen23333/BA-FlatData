
import flatbuffers
from flatbuffers.compat import import_numpy
np = import_numpy()

class MomotalkScheduleSpoilerPopupExcel:
    __slots__ = ['_tab']

    @classmethod
    def GetRootAs(cls, buf, offset=0):
        n = flatbuffers.encode.Get(flatbuffers.packer.uoffset, buf, offset)
        x = MomotalkScheduleSpoilerPopupExcel()
        x.Init(buf, n + offset)
        return x

    def Init(self, buf, pos):
        self._tab = flatbuffers.table.Table(buf, pos)


    def FavorScheduleId(self):
        o = flatbuffers.number_types.UOffsetTFlags.py_type(self._tab.Offset(4))
        if o != 0:
            return self._tab.Get(flatbuffers.number_types.Int32Flags, o + self._tab.Pos)
        return 0


    def SpoilerPopupTitle(self):
        o = flatbuffers.number_types.UOffsetTFlags.py_type(self._tab.Offset(6))
        if o != 0:
            return self._tab.Get(flatbuffers.number_types.Uint32Flags, o + self._tab.Pos)
        return 0


    def SpoilerPopupDescription(self):
        o = flatbuffers.number_types.UOffsetTFlags.py_type(self._tab.Offset(8))
        if o != 0:
            return self._tab.Get(flatbuffers.number_types.Uint32Flags, o + self._tab.Pos)
        return 0


    def PopupType(self):
        o = flatbuffers.number_types.UOffsetTFlags.py_type(self._tab.Offset(10))
        if o != 0:
            return self._tab.Get(flatbuffers.number_types.Int32Flags, o + self._tab.Pos)
        return 0


    def ConditionScenarioModeId(self):
        o = flatbuffers.number_types.UOffsetTFlags.py_type(self._tab.Offset(12))
        if o != 0:
            return self._tab.Get(flatbuffers.number_types.Int32Flags, o + self._tab.Pos)
        return 0




    @staticmethod
    def Start(builder): builder.StartObject(5)
    @staticmethod
    def End(builder): return builder.EndObject()


    @staticmethod
    def AddFavorScheduleId(builder, FavorScheduleId): builder.PrependInt32Slot(0, FavorScheduleId, 0)


    @staticmethod
    def AddSpoilerPopupTitle(builder, SpoilerPopupTitle): builder.PrependUint32Slot(1, SpoilerPopupTitle, 0)


    @staticmethod
    def AddSpoilerPopupDescription(builder, SpoilerPopupDescription): builder.PrependUint32Slot(2, SpoilerPopupDescription, 0)


    @staticmethod
    def AddPopupType(builder, PopupType): builder.PrependInt32Slot(3, PopupType, 0)


    @staticmethod
    def AddConditionScenarioModeId(builder, ConditionScenarioModeId): builder.PrependInt32Slot(4, ConditionScenarioModeId, 0)

