class RenderTextureReadWrite:
    Default = 0
    Linear = 1
    sRGB = 2
