class HelpBoxMessageType:
    None_ = 0
    Info = 1
    Warning = 2
    Error = 3
