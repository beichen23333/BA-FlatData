class Loglevels:
    All = 0
    Information = 1
    Warning = 2
    Error = 3
    Exception = 4
    None_ = 5
