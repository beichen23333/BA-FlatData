class MouthShape:
    Invalid = 0
    A = 1
    B = 2
    C = 3
    D = 4
    E = 5
    F = 6
    G = 7
    H = 8
    X = 9
    LastBasicShape = 10
