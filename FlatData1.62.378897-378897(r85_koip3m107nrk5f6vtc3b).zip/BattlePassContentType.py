class BattlePassContentType:
    Lobby = 0
    Mission = 1
