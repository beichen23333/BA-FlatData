class CharacterVoiceOverridePriority:
    None_ = 0
    High = 1
    Low = 2
