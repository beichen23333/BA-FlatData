class DreamMakerMultiplierCondition:
    None_ = 0
    Round = 1
    CollectionCount = 2
    EndingCount = 3
