class DialogConditionDetail:
    None_ = 0
    Day = 1
    Close = 2
    MiniGameDreamMakerDay = 3
    PassLevel = 4
