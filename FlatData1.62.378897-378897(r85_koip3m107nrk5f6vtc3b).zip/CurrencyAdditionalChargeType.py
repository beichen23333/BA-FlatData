class CurrencyAdditionalChargeType:
    EnableAutoChargeOverLimit = 0
    DisableAutoChargeOverLimit = 1
