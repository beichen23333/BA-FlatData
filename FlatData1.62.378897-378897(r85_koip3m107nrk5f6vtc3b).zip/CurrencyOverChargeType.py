class CurrencyOverChargeType:
    CanNotCharge = 0
    FitToLimit = 1
    ChargeOverLimit = 2
