class AttendanceCountRule:
    Accumulation = 0
    Date = 1
