class CoverMotionType:
    All = 0
    Kneel = 1
