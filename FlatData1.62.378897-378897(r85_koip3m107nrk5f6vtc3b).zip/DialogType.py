class DialogType:
    Talk = 0
    Think = 1
    UITalk = 2
