class BattleDialogType:
    Talk = 0
    Think = 1
    Shout = 2
