class DreamMakerVoiceCondition:
    None_ = 0
    Fail = 1
    Success = 2
    Perfect = 3
    DailyResult = 4
