class ConquestObjectType:
    None_ = 0
    ParcelOneTimePerAccount = 1
