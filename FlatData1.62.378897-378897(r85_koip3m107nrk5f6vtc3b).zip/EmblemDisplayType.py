class EmblemDisplayType:
    Always = 0
    Time = 1
    Favor = 2
    Potential = 3
