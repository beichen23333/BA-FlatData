class AttackType:
    Single = 0
    Splash = 1
    Through = 2
    Heal = 3
