class DreamMakerEndingRewardType:
    None_ = 0
    FirstEndingReward = 1
    LoopEndingReward = 2
