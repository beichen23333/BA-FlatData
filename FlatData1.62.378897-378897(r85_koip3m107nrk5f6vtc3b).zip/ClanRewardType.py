class ClanRewardType:
    None_ = 0
    AssistTerm = 1
    AssistRent = 2
    Attendance = 3
