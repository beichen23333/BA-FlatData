class ActionType:
    Crush = 0
    Courage = 1
    Tactic = 2
