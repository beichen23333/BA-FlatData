class EndCondition:
    Duration = 0
    ReloadCount = 1
    AmmoCount = 2
    AmmoHit = 3
    HitCount = 4
    None_ = 5
    UseExSkillCount = 6
    UseTargetSlotExSkillCount = 7
    UseExSkillOverloadedCount = 8
