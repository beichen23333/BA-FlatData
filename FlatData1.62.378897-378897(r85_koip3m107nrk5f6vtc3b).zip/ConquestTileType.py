class ConquestTileType:
    None_ = 0
    Start = 1
    Normal = 2
    Battle = 3
    Base = 4
