class CVPrintType:
    CharacterOverwrite = 0
    PrefabOverwrite = 1
    Add = 2
