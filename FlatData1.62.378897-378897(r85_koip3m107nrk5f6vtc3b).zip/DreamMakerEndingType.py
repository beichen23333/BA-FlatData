class DreamMakerEndingType:
    None_ = 0
    Normal = 1
    Special = 2
