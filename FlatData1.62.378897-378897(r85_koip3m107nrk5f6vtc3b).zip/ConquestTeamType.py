class ConquestTeamType:
    None_ = 0
    Team1 = 1
    Team2 = 2
    Team3 = 3
