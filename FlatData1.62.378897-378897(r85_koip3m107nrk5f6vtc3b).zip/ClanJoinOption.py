class ClanJoinOption:
    Free = 0
    Permission = 1
    All = 2
