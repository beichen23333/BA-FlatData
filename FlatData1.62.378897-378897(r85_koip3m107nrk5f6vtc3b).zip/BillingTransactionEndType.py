class BillingTransactionEndType:
    None_ = 0
    Success = 1
    Cancel = 2
