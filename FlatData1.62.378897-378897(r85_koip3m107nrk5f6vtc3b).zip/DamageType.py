class DamageType:
    Normal = 0
    Critical = 1
    IgnoreDefence = 2
