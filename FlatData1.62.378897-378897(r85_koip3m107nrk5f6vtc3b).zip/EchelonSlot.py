class EchelonSlot:
    None_ = 0
    StrikerEchelon = 1
    SpecialEchelon = 2
