class ConquestErosionType:
    None_ = 0
    IndividualErosion = 1
    MassErosion = 2
