class DamageFontColor:
    Blue = 0
    White = 1
    Yellow = 2
    Red = 3
    Green = 4
