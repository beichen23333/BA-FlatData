class CraftNodeTier:
    Base = 0
    Node01 = 1
    Node02 = 2
    Node03 = 3
    Max = 4
