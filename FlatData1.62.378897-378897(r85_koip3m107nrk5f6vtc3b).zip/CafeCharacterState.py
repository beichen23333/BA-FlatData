class CafeCharacterState:
    None_ = 0
    Idle = 1
    Walk = 2
    Reaction = 3
    Interaction = 4
    Max = 5
