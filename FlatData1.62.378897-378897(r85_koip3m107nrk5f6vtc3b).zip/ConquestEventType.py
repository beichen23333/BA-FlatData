class ConquestEventType:
    None_ = 0
    Event01 = 1
    Event02 = 2
