class Anniversary:
    None_ = 0
    UserBDay = 1
    StudentBDay = 2
