class ConcentrationRewardType:
    None_ = 0
    CardOpen = 1
    PairMatch = 2
    RoundRenewal = 3
