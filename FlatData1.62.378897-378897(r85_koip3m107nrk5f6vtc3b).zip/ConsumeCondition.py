class ConsumeCondition:
    And = 0
    Or = 1
