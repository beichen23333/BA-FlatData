class CVCollectionType:
    CVNormal = 0
    CVEvent = 1
    CVEtc = 2
