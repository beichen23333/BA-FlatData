class AcademyMessageTypes:
    None_ = 0
    Text = 1
    Image = 2
