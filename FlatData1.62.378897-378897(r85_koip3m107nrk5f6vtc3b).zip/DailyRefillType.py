class DailyRefillType:
    None_ = 0
    Default = 1
    Login = 2
