class BuffOverlap:
    Able = 0
    Unable = 1
    Change = 2
    Additive = 3
