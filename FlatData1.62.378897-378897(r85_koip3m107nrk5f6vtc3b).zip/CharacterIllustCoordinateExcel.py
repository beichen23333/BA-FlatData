
import flatbuffers
from flatbuffers.compat import import_numpy
np = import_numpy()

class CharacterIllustCoordinateExcel:
    __slots__ = ['_tab']

    @classmethod
    def GetRootAs(cls, buf, offset=0):
        n = flatbuffers.encode.Get(flatbuffers.packer.uoffset, buf, offset)
        x = CharacterIllustCoordinateExcel()
        x.Init(buf, n + offset)
        return x

    def Init(self, buf, pos):
        self._tab = flatbuffers.table.Table(buf, pos)


    def Id(self):
        o = flatbuffers.number_types.UOffsetTFlags.py_type(self._tab.Offset(4))
        if o != 0:
            return self._tab.Get(flatbuffers.number_types.Int64Flags, o + self._tab.Pos)
        return 0


    def CharacterBodyCenterX(self):
        o = flatbuffers.number_types.UOffsetTFlags.py_type(self._tab.Offset(6))
        if o != 0:
            return self._tab.Get(flatbuffers.number_types.Float32Flags, o + self._tab.Pos)
        return 0


    def CharacterBodyCenterY(self):
        o = flatbuffers.number_types.UOffsetTFlags.py_type(self._tab.Offset(8))
        if o != 0:
            return self._tab.Get(flatbuffers.number_types.Float32Flags, o + self._tab.Pos)
        return 0


    def DefaultScale(self):
        o = flatbuffers.number_types.UOffsetTFlags.py_type(self._tab.Offset(10))
        if o != 0:
            return self._tab.Get(flatbuffers.number_types.Float32Flags, o + self._tab.Pos)
        return 0


    def MinScale(self):
        o = flatbuffers.number_types.UOffsetTFlags.py_type(self._tab.Offset(12))
        if o != 0:
            return self._tab.Get(flatbuffers.number_types.Float32Flags, o + self._tab.Pos)
        return 0


    def MaxScale(self):
        o = flatbuffers.number_types.UOffsetTFlags.py_type(self._tab.Offset(14))
        if o != 0:
            return self._tab.Get(flatbuffers.number_types.Float32Flags, o + self._tab.Pos)
        return 0




    @staticmethod
    def Start(builder): builder.StartObject(6)
    @staticmethod
    def End(builder): return builder.EndObject()


    @staticmethod
    def AddId(builder, Id): builder.PrependInt64Slot(0, Id, 0)


    @staticmethod
    def AddCharacterBodyCenterX(builder, CharacterBodyCenterX): builder.PrependFloat32Slot(1, CharacterBodyCenterX, 0)


    @staticmethod
    def AddCharacterBodyCenterY(builder, CharacterBodyCenterY): builder.PrependFloat32Slot(2, CharacterBodyCenterY, 0)


    @staticmethod
    def AddDefaultScale(builder, DefaultScale): builder.PrependFloat32Slot(3, DefaultScale, 0)


    @staticmethod
    def AddMinScale(builder, MinScale): builder.PrependFloat32Slot(4, MinScale, 0)


    @staticmethod
    def AddMaxScale(builder, MaxScale): builder.PrependFloat32Slot(5, MaxScale, 0)

