class CCGCardType:
    None_ = 0
    Spell = 1
    Equipment = 2
    Zone = 3
