class EventContentScenarioConditionType:
    None_ = 0
    DayAfter = 1
    EventPoint = 2
