class AmplifyDoTRemoveCondition:
    None_ = 0
    ApplyCount = 1
