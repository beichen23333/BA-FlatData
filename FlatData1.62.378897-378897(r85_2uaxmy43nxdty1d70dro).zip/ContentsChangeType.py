class ContentsChangeType:
    None_ = 0
    WorldRaidBossDamageRatio = 1
    WorldRaidBossGroupDate = 2
