class CVExceptionTarget:
    CharacterId = 0
    SquadType = 1
