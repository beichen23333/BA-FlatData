class AttendanceResetType:
    User = 0
    Server = 1
