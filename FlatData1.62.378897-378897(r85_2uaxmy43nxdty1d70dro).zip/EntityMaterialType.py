class EntityMaterialType:
    Wood = 0
    Stone = 1
    Flesh = 2
    Metal = 3
