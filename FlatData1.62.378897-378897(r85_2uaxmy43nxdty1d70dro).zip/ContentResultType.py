class ContentResultType:
    Failure = 0
    Success = 1
