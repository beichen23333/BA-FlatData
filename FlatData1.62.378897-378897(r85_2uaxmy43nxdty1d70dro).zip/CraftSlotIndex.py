class CraftSlotIndex:
    Slot00 = 0
    Slot01 = 1
    Slot02 = 2
    Max = 3
