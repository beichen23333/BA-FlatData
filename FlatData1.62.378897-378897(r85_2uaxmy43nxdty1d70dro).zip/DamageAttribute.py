class DamageAttribute:
    Resist = 0
    Normal = 1
    Weak = 2
    Effective = 3
