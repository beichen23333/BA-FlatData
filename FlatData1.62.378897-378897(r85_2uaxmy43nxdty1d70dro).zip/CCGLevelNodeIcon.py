class CCGLevelNodeIcon:
    None_ = 0
    Battle = 1
    Event = 2
    Camp = 3
    Boss = 4
