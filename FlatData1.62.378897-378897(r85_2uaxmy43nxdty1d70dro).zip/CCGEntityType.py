class CCGEntityType:
    None_ = 0
    Character = 1
    Card = 2
