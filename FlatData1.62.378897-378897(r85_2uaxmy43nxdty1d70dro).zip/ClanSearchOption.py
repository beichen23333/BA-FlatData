class ClanSearchOption:
    Name = 0
    Id = 1
