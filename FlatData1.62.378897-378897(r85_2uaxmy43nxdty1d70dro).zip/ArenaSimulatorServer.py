class ArenaSimulatorServer:
    Preset = 0
    Live = 1
    Dev = 2
    QA = 3
