class EngageType:
    SearchAndMove = 0
    HoldPosition = 1
