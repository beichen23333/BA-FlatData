class CVUnlockScenarioType:
    Main = 0
    Event = 1
    SpecialOperation = 2
