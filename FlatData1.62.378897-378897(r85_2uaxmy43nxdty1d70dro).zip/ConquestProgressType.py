class ConquestProgressType:
    None_ = 0
    Upgrade = 1
    Manage = 2
