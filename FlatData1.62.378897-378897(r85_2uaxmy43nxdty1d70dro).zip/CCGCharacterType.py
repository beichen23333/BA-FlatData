class CCGCharacterType:
    None_ = 0
    Striker = 1
    Special = 2
