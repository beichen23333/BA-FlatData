class EmblemCheckPassType:
    None_ = 0
    Default = 1
    Favor = 2
    Story = 3
    Potential = 4
