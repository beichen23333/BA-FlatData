class EventChangeType:
    MainSub = 0
    SubMain = 1
