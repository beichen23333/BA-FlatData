class AssistRewardType:
    None_ = 0
    AssistTerm = 1
    AssistRent = 2
