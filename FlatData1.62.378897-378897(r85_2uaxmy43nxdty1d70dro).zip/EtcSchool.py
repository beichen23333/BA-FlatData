class EtcSchool:
    None_ = 0
    ETC = 1
    Tokiwadai = 2
    Sakugawa = 3
    Max = 4
