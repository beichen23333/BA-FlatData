class CCGStageRewardType:
    None_ = 0
    All = 1
    Random = 2
    Select = 3
