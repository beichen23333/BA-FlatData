class EchelonExtensionType:
    Base = 0
    Extension = 1
