class ShaderPropertyType:
    Color = 0
    Vector = 1
    Float = 2
    Range = 3
    Texture = 4
    Int = 5
