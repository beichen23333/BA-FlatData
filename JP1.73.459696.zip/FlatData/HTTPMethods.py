class HTTPMethods:
    Get = 0
    Head = 1
    Post = 2
    Put = 3
    Delete = 4
    Patch = 5
    Merge = 6
    Options = 7
