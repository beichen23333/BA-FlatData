class IMECompositionMode:
    Auto = 0
    On = 1
    Off = 2
