
import flatbuffers
from flatbuffers.compat import import_numpy
np = import_numpy()

class GroundExcel:
    __slots__ = ['_tab']

    @classmethod
    def GetRootAs(cls, buf, offset=0):
        n = flatbuffers.encode.Get(flatbuffers.packer.uoffset, buf, offset)
        x = GroundExcel()
        x.Init(buf, n + offset)
        return x

    def Init(self, buf, pos):
        self._tab = flatbuffers.table.Table(buf, pos)


    def Id(self):
        o = flatbuffers.number_types.UOffsetTFlags.py_type(self._tab.Offset(4))
        if o != 0:
            return self._tab.Get(flatbuffers.number_types.Int32Flags, o + self._tab.Pos)
        return 0


    def StageFileNameLength(self):
        o = flatbuffers.number_types.UOffsetTFlags.py_type(self._tab.Offset(6))
        if o != 0:
            return self._tab.Get(flatbuffers.number_types.Int32Flags, o + self._tab.Pos)
        return 0


    def GroundSceneName(self):
        o = flatbuffers.number_types.UOffsetTFlags.py_type(self._tab.Offset(8))
        if o != 0:
            return self._tab.String(o + self._tab.Pos)
        return None


    def FormationGroupId(self):
        o = flatbuffers.number_types.UOffsetTFlags.py_type(self._tab.Offset(10))
        if o != 0:
            return self._tab.Get(flatbuffers.number_types.Int32Flags, o + self._tab.Pos)
        return 0


    def StageTopography(self):
        o = flatbuffers.number_types.UOffsetTFlags.py_type(self._tab.Offset(12))
        if o != 0:
            return self._tab.Get(flatbuffers.number_types.Int32Flags, o + self._tab.Pos)
        return 0


    def EnemyBulletType(self):
        o = flatbuffers.number_types.UOffsetTFlags.py_type(self._tab.Offset(14))
        if o != 0:
            return self._tab.Get(flatbuffers.number_types.Int32Flags, o + self._tab.Pos)
        return 0


    def EnemyArmorType(self):
        o = flatbuffers.number_types.UOffsetTFlags.py_type(self._tab.Offset(16))
        if o != 0:
            return self._tab.Get(flatbuffers.number_types.Int32Flags, o + self._tab.Pos)
        return 0


    def EnemySubArmorType(self):
        o = flatbuffers.number_types.UOffsetTFlags.py_type(self._tab.Offset(18))
        if o != 0:
            return self._tab.Get(flatbuffers.number_types.Int32Flags, o + self._tab.Pos)
        return 0


    def LevelNPC(self):
        o = flatbuffers.number_types.UOffsetTFlags.py_type(self._tab.Offset(20))
        if o != 0:
            return self._tab.Get(flatbuffers.number_types.Int32Flags, o + self._tab.Pos)
        return 0


    def LevelMinion(self):
        o = flatbuffers.number_types.UOffsetTFlags.py_type(self._tab.Offset(22))
        if o != 0:
            return self._tab.Get(flatbuffers.number_types.Int32Flags, o + self._tab.Pos)
        return 0


    def LevelElite(self):
        o = flatbuffers.number_types.UOffsetTFlags.py_type(self._tab.Offset(24))
        if o != 0:
            return self._tab.Get(flatbuffers.number_types.Int32Flags, o + self._tab.Pos)
        return 0


    def LevelChampion(self):
        o = flatbuffers.number_types.UOffsetTFlags.py_type(self._tab.Offset(26))
        if o != 0:
            return self._tab.Get(flatbuffers.number_types.Int32Flags, o + self._tab.Pos)
        return 0


    def LevelBoss(self):
        o = flatbuffers.number_types.UOffsetTFlags.py_type(self._tab.Offset(28))
        if o != 0:
            return self._tab.Get(flatbuffers.number_types.Int32Flags, o + self._tab.Pos)
        return 0


    def ObstacleLevel(self):
        o = flatbuffers.number_types.UOffsetTFlags.py_type(self._tab.Offset(30))
        if o != 0:
            return self._tab.Get(flatbuffers.number_types.Int32Flags, o + self._tab.Pos)
        return 0


    def GradeNPC(self):
        o = flatbuffers.number_types.UOffsetTFlags.py_type(self._tab.Offset(32))
        if o != 0:
            return self._tab.Get(flatbuffers.number_types.Int32Flags, o + self._tab.Pos)
        return 0


    def GradeMinion(self):
        o = flatbuffers.number_types.UOffsetTFlags.py_type(self._tab.Offset(34))
        if o != 0:
            return self._tab.Get(flatbuffers.number_types.Int32Flags, o + self._tab.Pos)
        return 0


    def GradeElite(self):
        o = flatbuffers.number_types.UOffsetTFlags.py_type(self._tab.Offset(36))
        if o != 0:
            return self._tab.Get(flatbuffers.number_types.Int32Flags, o + self._tab.Pos)
        return 0


    def GradeChampion(self):
        o = flatbuffers.number_types.UOffsetTFlags.py_type(self._tab.Offset(38))
        if o != 0:
            return self._tab.Get(flatbuffers.number_types.Int32Flags, o + self._tab.Pos)
        return 0


    def GradeBoss(self):
        o = flatbuffers.number_types.UOffsetTFlags.py_type(self._tab.Offset(40))
        if o != 0:
            return self._tab.Get(flatbuffers.number_types.Int32Flags, o + self._tab.Pos)
        return 0


    def PlayerSightPointAdd(self):
        o = flatbuffers.number_types.UOffsetTFlags.py_type(self._tab.Offset(42))
        if o != 0:
            return self._tab.Get(flatbuffers.number_types.Int32Flags, o + self._tab.Pos)
        return 0


    def PlayerSightPointRate(self):
        o = flatbuffers.number_types.UOffsetTFlags.py_type(self._tab.Offset(44))
        if o != 0:
            return self._tab.Get(flatbuffers.number_types.Int32Flags, o + self._tab.Pos)
        return 0


    def PlayerAttackRangeAdd(self):
        o = flatbuffers.number_types.UOffsetTFlags.py_type(self._tab.Offset(46))
        if o != 0:
            return self._tab.Get(flatbuffers.number_types.Int32Flags, o + self._tab.Pos)
        return 0


    def PlayerAttackRangeRate(self):
        o = flatbuffers.number_types.UOffsetTFlags.py_type(self._tab.Offset(48))
        if o != 0:
            return self._tab.Get(flatbuffers.number_types.Int32Flags, o + self._tab.Pos)
        return 0


    def EnemySightPointAdd(self):
        o = flatbuffers.number_types.UOffsetTFlags.py_type(self._tab.Offset(50))
        if o != 0:
            return self._tab.Get(flatbuffers.number_types.Int32Flags, o + self._tab.Pos)
        return 0


    def EnemySightPointRate(self):
        o = flatbuffers.number_types.UOffsetTFlags.py_type(self._tab.Offset(52))
        if o != 0:
            return self._tab.Get(flatbuffers.number_types.Int32Flags, o + self._tab.Pos)
        return 0


    def EnemyAttackRangeAdd(self):
        o = flatbuffers.number_types.UOffsetTFlags.py_type(self._tab.Offset(54))
        if o != 0:
            return self._tab.Get(flatbuffers.number_types.Int32Flags, o + self._tab.Pos)
        return 0


    def EnemyAttackRangeRate(self):
        o = flatbuffers.number_types.UOffsetTFlags.py_type(self._tab.Offset(56))
        if o != 0:
            return self._tab.Get(flatbuffers.number_types.Int32Flags, o + self._tab.Pos)
        return 0


    def PlayerSkillRangeAdd(self):
        o = flatbuffers.number_types.UOffsetTFlags.py_type(self._tab.Offset(58))
        if o != 0:
            return self._tab.Get(flatbuffers.number_types.Int32Flags, o + self._tab.Pos)
        return 0


    def PlayerSkillRangeRate(self):
        o = flatbuffers.number_types.UOffsetTFlags.py_type(self._tab.Offset(60))
        if o != 0:
            return self._tab.Get(flatbuffers.number_types.Int32Flags, o + self._tab.Pos)
        return 0


    def EnemySkillRangeAdd(self):
        o = flatbuffers.number_types.UOffsetTFlags.py_type(self._tab.Offset(62))
        if o != 0:
            return self._tab.Get(flatbuffers.number_types.Int32Flags, o + self._tab.Pos)
        return 0


    def EnemySkillRangeRate(self):
        o = flatbuffers.number_types.UOffsetTFlags.py_type(self._tab.Offset(64))
        if o != 0:
            return self._tab.Get(flatbuffers.number_types.Int32Flags, o + self._tab.Pos)
        return 0


    def PlayerMinimumPositionGapRate(self):
        o = flatbuffers.number_types.UOffsetTFlags.py_type(self._tab.Offset(66))
        if o != 0:
            return self._tab.Get(flatbuffers.number_types.Int32Flags, o + self._tab.Pos)
        return 0


    def EnemyMinimumPositionGapRate(self):
        o = flatbuffers.number_types.UOffsetTFlags.py_type(self._tab.Offset(68))
        if o != 0:
            return self._tab.Get(flatbuffers.number_types.Int32Flags, o + self._tab.Pos)
        return 0


    def PlayerSightRangeMax(self):
        o = flatbuffers.number_types.UOffsetTFlags.py_type(self._tab.Offset(70))
        if o != 0:
            return self._tab.Get(flatbuffers.number_types.BoolFlags, o + self._tab.Pos)
        return 0


    def EnemySightRangeMax(self):
        o = flatbuffers.number_types.UOffsetTFlags.py_type(self._tab.Offset(72))
        if o != 0:
            return self._tab.Get(flatbuffers.number_types.BoolFlags, o + self._tab.Pos)
        return 0


    def TSSAirUnitHeight(self):
        o = flatbuffers.number_types.UOffsetTFlags.py_type(self._tab.Offset(74))
        if o != 0:
            return self._tab.Get(flatbuffers.number_types.Int32Flags, o + self._tab.Pos)
        return 0


    def IsPhaseBGM(self):
        o = flatbuffers.number_types.UOffsetTFlags.py_type(self._tab.Offset(76))
        if o != 0:
            return self._tab.Get(flatbuffers.number_types.BoolFlags, o + self._tab.Pos)
        return 0


    def BGMId(self):
        o = flatbuffers.number_types.UOffsetTFlags.py_type(self._tab.Offset(78))
        if o != 0:
            return self._tab.Get(flatbuffers.number_types.Int32Flags, o + self._tab.Pos)
        return 0


    def WarningUI(self):
        o = flatbuffers.number_types.UOffsetTFlags.py_type(self._tab.Offset(80))
        if o != 0:
            return self._tab.Get(flatbuffers.number_types.BoolFlags, o + self._tab.Pos)
        return 0


    def TSSHatchOpen(self):
        o = flatbuffers.number_types.UOffsetTFlags.py_type(self._tab.Offset(82))
        if o != 0:
            return self._tab.Get(flatbuffers.number_types.BoolFlags, o + self._tab.Pos)
        return 0


    def ForcedTacticSpeed(self):
        o = flatbuffers.number_types.UOffsetTFlags.py_type(self._tab.Offset(84))
        if o != 0:
            return self._tab.Get(flatbuffers.number_types.Int32Flags, o + self._tab.Pos)
        return 0


    def ForcedSkillUse(self):
        o = flatbuffers.number_types.UOffsetTFlags.py_type(self._tab.Offset(86))
        if o != 0:
            return self._tab.Get(flatbuffers.number_types.Int32Flags, o + self._tab.Pos)
        return 0


    def ShowNPCSkillCutIn(self):
        o = flatbuffers.number_types.UOffsetTFlags.py_type(self._tab.Offset(88))
        if o != 0:
            return self._tab.Get(flatbuffers.number_types.Int32Flags, o + self._tab.Pos)
        return 0


    def ImmuneHitBeforeTimeOutEnd(self):
        o = flatbuffers.number_types.UOffsetTFlags.py_type(self._tab.Offset(90))
        if o != 0:
            return self._tab.Get(flatbuffers.number_types.BoolFlags, o + self._tab.Pos)
        return 0


    def UIBattleHideFromScratch(self):
        o = flatbuffers.number_types.UOffsetTFlags.py_type(self._tab.Offset(92))
        if o != 0:
            return self._tab.Get(flatbuffers.number_types.BoolFlags, o + self._tab.Pos)
        return 0


    def UIEnemyCount(self):
        o = flatbuffers.number_types.UOffsetTFlags.py_type(self._tab.Offset(94))
        if o != 0:
            return self._tab.Get(flatbuffers.number_types.Int32Flags, o + self._tab.Pos)
        return 0


    def BattleReadyTimelinePath(self):
        o = flatbuffers.number_types.UOffsetTFlags.py_type(self._tab.Offset(96))
        if o != 0:
            return self._tab.String(o + self._tab.Pos)
        return None


    def BeforeVictoryTimelinePath(self):
        o = flatbuffers.number_types.UOffsetTFlags.py_type(self._tab.Offset(98))
        if o != 0:
            return self._tab.String(o + self._tab.Pos)
        return None


    def SkipBattleEnd(self):
        o = flatbuffers.number_types.UOffsetTFlags.py_type(self._tab.Offset(100))
        if o != 0:
            return self._tab.Get(flatbuffers.number_types.BoolFlags, o + self._tab.Pos)
        return 0


    def HideNPCWhenBattleEnd(self):
        o = flatbuffers.number_types.UOffsetTFlags.py_type(self._tab.Offset(102))
        if o != 0:
            return self._tab.Get(flatbuffers.number_types.BoolFlags, o + self._tab.Pos)
        return 0


    def CoverPointOff(self):
        o = flatbuffers.number_types.UOffsetTFlags.py_type(self._tab.Offset(104))
        if o != 0:
            return self._tab.Get(flatbuffers.number_types.BoolFlags, o + self._tab.Pos)
        return 0


    def UIHpScale(self):
        o = flatbuffers.number_types.UOffsetTFlags.py_type(self._tab.Offset(106))
        if o != 0:
            return self._tab.Get(flatbuffers.number_types.Float32Flags, o + self._tab.Pos)
        return 0


    def UIEmojiScale(self):
        o = flatbuffers.number_types.UOffsetTFlags.py_type(self._tab.Offset(108))
        if o != 0:
            return self._tab.Get(flatbuffers.number_types.Float32Flags, o + self._tab.Pos)
        return 0


    def UISkillMainLogScale(self):
        o = flatbuffers.number_types.UOffsetTFlags.py_type(self._tab.Offset(110))
        if o != 0:
            return self._tab.Get(flatbuffers.number_types.Float32Flags, o + self._tab.Pos)
        return 0


    def EffectCountLimit(self):
        o = flatbuffers.number_types.UOffsetTFlags.py_type(self._tab.Offset(112))
        if o != 0:
            return self._tab.Get(flatbuffers.number_types.Int32Flags, o + self._tab.Pos)
        return 0


    def CarrierSkillGroupId(self):
        o = flatbuffers.number_types.UOffsetTFlags.py_type(self._tab.Offset(114))
        if o != 0:
            return self._tab.Get(flatbuffers.number_types.Int32Flags, o + self._tab.Pos)
        return 0


    def AllyPassiveSkillIdLength(self):
        o = flatbuffers.number_types.UOffsetTFlags.py_type(self._tab.Offset(116))
        if o != 0:
            return self._tab.Get(flatbuffers.number_types.Int32Flags, o + self._tab.Pos)
        return 0


    def AllyPassiveSkillLevelLength(self):
        o = flatbuffers.number_types.UOffsetTFlags.py_type(self._tab.Offset(118))
        if o != 0:
            return self._tab.Get(flatbuffers.number_types.Int32Flags, o + self._tab.Pos)
        return 0


    def EnemyPassiveSkillIdLength(self):
        o = flatbuffers.number_types.UOffsetTFlags.py_type(self._tab.Offset(120))
        if o != 0:
            return self._tab.Get(flatbuffers.number_types.Int32Flags, o + self._tab.Pos)
        return 0


    def EnemyPassiveSkillLevelLength(self):
        o = flatbuffers.number_types.UOffsetTFlags.py_type(self._tab.Offset(122))
        if o != 0:
            return self._tab.Get(flatbuffers.number_types.Int32Flags, o + self._tab.Pos)
        return 0




    @staticmethod
    def Start(builder): builder.StartObject(60)
    @staticmethod
    def End(builder): return builder.EndObject()


    @staticmethod
    def AddId(builder, Id): builder.PrependInt32Slot(0, Id, 0)


    @staticmethod
    def AddStageFileNameLength(builder, StageFileNameLength): builder.PrependInt32Slot(1, StageFileNameLength, 0)


    @staticmethod
    def AddGroundSceneName(builder, GroundSceneName): builder.PrependUOffsetTRelativeSlot(2, flatbuffers.number_types.UOffsetTFlags.py_type(GroundSceneName), 0)

    @staticmethod
    def AddFormationGroupId(builder, FormationGroupId): builder.PrependInt32Slot(3, FormationGroupId, 0)


    @staticmethod
    def AddStageTopography(builder, StageTopography): builder.PrependInt32Slot(4, StageTopography, 0)


    @staticmethod
    def AddEnemyBulletType(builder, EnemyBulletType): builder.PrependInt32Slot(5, EnemyBulletType, 0)


    @staticmethod
    def AddEnemyArmorType(builder, EnemyArmorType): builder.PrependInt32Slot(6, EnemyArmorType, 0)


    @staticmethod
    def AddEnemySubArmorType(builder, EnemySubArmorType): builder.PrependInt32Slot(7, EnemySubArmorType, 0)


    @staticmethod
    def AddLevelNPC(builder, LevelNPC): builder.PrependInt32Slot(8, LevelNPC, 0)


    @staticmethod
    def AddLevelMinion(builder, LevelMinion): builder.PrependInt32Slot(9, LevelMinion, 0)


    @staticmethod
    def AddLevelElite(builder, LevelElite): builder.PrependInt32Slot(10, LevelElite, 0)


    @staticmethod
    def AddLevelChampion(builder, LevelChampion): builder.PrependInt32Slot(11, LevelChampion, 0)


    @staticmethod
    def AddLevelBoss(builder, LevelBoss): builder.PrependInt32Slot(12, LevelBoss, 0)


    @staticmethod
    def AddObstacleLevel(builder, ObstacleLevel): builder.PrependInt32Slot(13, ObstacleLevel, 0)


    @staticmethod
    def AddGradeNPC(builder, GradeNPC): builder.PrependInt32Slot(14, GradeNPC, 0)


    @staticmethod
    def AddGradeMinion(builder, GradeMinion): builder.PrependInt32Slot(15, GradeMinion, 0)


    @staticmethod
    def AddGradeElite(builder, GradeElite): builder.PrependInt32Slot(16, GradeElite, 0)


    @staticmethod
    def AddGradeChampion(builder, GradeChampion): builder.PrependInt32Slot(17, GradeChampion, 0)


    @staticmethod
    def AddGradeBoss(builder, GradeBoss): builder.PrependInt32Slot(18, GradeBoss, 0)


    @staticmethod
    def AddPlayerSightPointAdd(builder, PlayerSightPointAdd): builder.PrependInt32Slot(19, PlayerSightPointAdd, 0)


    @staticmethod
    def AddPlayerSightPointRate(builder, PlayerSightPointRate): builder.PrependInt32Slot(20, PlayerSightPointRate, 0)


    @staticmethod
    def AddPlayerAttackRangeAdd(builder, PlayerAttackRangeAdd): builder.PrependInt32Slot(21, PlayerAttackRangeAdd, 0)


    @staticmethod
    def AddPlayerAttackRangeRate(builder, PlayerAttackRangeRate): builder.PrependInt32Slot(22, PlayerAttackRangeRate, 0)


    @staticmethod
    def AddEnemySightPointAdd(builder, EnemySightPointAdd): builder.PrependInt32Slot(23, EnemySightPointAdd, 0)


    @staticmethod
    def AddEnemySightPointRate(builder, EnemySightPointRate): builder.PrependInt32Slot(24, EnemySightPointRate, 0)


    @staticmethod
    def AddEnemyAttackRangeAdd(builder, EnemyAttackRangeAdd): builder.PrependInt32Slot(25, EnemyAttackRangeAdd, 0)


    @staticmethod
    def AddEnemyAttackRangeRate(builder, EnemyAttackRangeRate): builder.PrependInt32Slot(26, EnemyAttackRangeRate, 0)


    @staticmethod
    def AddPlayerSkillRangeAdd(builder, PlayerSkillRangeAdd): builder.PrependInt32Slot(27, PlayerSkillRangeAdd, 0)


    @staticmethod
    def AddPlayerSkillRangeRate(builder, PlayerSkillRangeRate): builder.PrependInt32Slot(28, PlayerSkillRangeRate, 0)


    @staticmethod
    def AddEnemySkillRangeAdd(builder, EnemySkillRangeAdd): builder.PrependInt32Slot(29, EnemySkillRangeAdd, 0)


    @staticmethod
    def AddEnemySkillRangeRate(builder, EnemySkillRangeRate): builder.PrependInt32Slot(30, EnemySkillRangeRate, 0)


    @staticmethod
    def AddPlayerMinimumPositionGapRate(builder, PlayerMinimumPositionGapRate): builder.PrependInt32Slot(31, PlayerMinimumPositionGapRate, 0)


    @staticmethod
    def AddEnemyMinimumPositionGapRate(builder, EnemyMinimumPositionGapRate): builder.PrependInt32Slot(32, EnemyMinimumPositionGapRate, 0)


    @staticmethod
    def AddPlayerSightRangeMax(builder, PlayerSightRangeMax): builder.PrependBoolSlot(33, PlayerSightRangeMax, 0)


    @staticmethod
    def AddEnemySightRangeMax(builder, EnemySightRangeMax): builder.PrependBoolSlot(34, EnemySightRangeMax, 0)


    @staticmethod
    def AddTSSAirUnitHeight(builder, TSSAirUnitHeight): builder.PrependInt32Slot(35, TSSAirUnitHeight, 0)


    @staticmethod
    def AddIsPhaseBGM(builder, IsPhaseBGM): builder.PrependBoolSlot(36, IsPhaseBGM, 0)


    @staticmethod
    def AddBGMId(builder, BGMId): builder.PrependInt32Slot(37, BGMId, 0)


    @staticmethod
    def AddWarningUI(builder, WarningUI): builder.PrependBoolSlot(38, WarningUI, 0)


    @staticmethod
    def AddTSSHatchOpen(builder, TSSHatchOpen): builder.PrependBoolSlot(39, TSSHatchOpen, 0)


    @staticmethod
    def AddForcedTacticSpeed(builder, ForcedTacticSpeed): builder.PrependInt32Slot(40, ForcedTacticSpeed, 0)


    @staticmethod
    def AddForcedSkillUse(builder, ForcedSkillUse): builder.PrependInt32Slot(41, ForcedSkillUse, 0)


    @staticmethod
    def AddShowNPCSkillCutIn(builder, ShowNPCSkillCutIn): builder.PrependInt32Slot(42, ShowNPCSkillCutIn, 0)


    @staticmethod
    def AddImmuneHitBeforeTimeOutEnd(builder, ImmuneHitBeforeTimeOutEnd): builder.PrependBoolSlot(43, ImmuneHitBeforeTimeOutEnd, 0)


    @staticmethod
    def AddUIBattleHideFromScratch(builder, UIBattleHideFromScratch): builder.PrependBoolSlot(44, UIBattleHideFromScratch, 0)


    @staticmethod
    def AddUIEnemyCount(builder, UIEnemyCount): builder.PrependInt32Slot(45, UIEnemyCount, 0)


    @staticmethod
    def AddBattleReadyTimelinePath(builder, BattleReadyTimelinePath): builder.PrependUOffsetTRelativeSlot(46, flatbuffers.number_types.UOffsetTFlags.py_type(BattleReadyTimelinePath), 0)

    @staticmethod
    def AddBeforeVictoryTimelinePath(builder, BeforeVictoryTimelinePath): builder.PrependUOffsetTRelativeSlot(47, flatbuffers.number_types.UOffsetTFlags.py_type(BeforeVictoryTimelinePath), 0)

    @staticmethod
    def AddSkipBattleEnd(builder, SkipBattleEnd): builder.PrependBoolSlot(48, SkipBattleEnd, 0)


    @staticmethod
    def AddHideNPCWhenBattleEnd(builder, HideNPCWhenBattleEnd): builder.PrependBoolSlot(49, HideNPCWhenBattleEnd, 0)


    @staticmethod
    def AddCoverPointOff(builder, CoverPointOff): builder.PrependBoolSlot(50, CoverPointOff, 0)


    @staticmethod
    def AddUIHpScale(builder, UIHpScale): builder.PrependFloat32Slot(51, UIHpScale, 0)


    @staticmethod
    def AddUIEmojiScale(builder, UIEmojiScale): builder.PrependFloat32Slot(52, UIEmojiScale, 0)


    @staticmethod
    def AddUISkillMainLogScale(builder, UISkillMainLogScale): builder.PrependFloat32Slot(53, UISkillMainLogScale, 0)


    @staticmethod
    def AddEffectCountLimit(builder, EffectCountLimit): builder.PrependInt32Slot(54, EffectCountLimit, 0)


    @staticmethod
    def AddCarrierSkillGroupId(builder, CarrierSkillGroupId): builder.PrependInt32Slot(55, CarrierSkillGroupId, 0)


    @staticmethod
    def AddAllyPassiveSkillIdLength(builder, AllyPassiveSkillIdLength): builder.PrependInt32Slot(56, AllyPassiveSkillIdLength, 0)


    @staticmethod
    def AddAllyPassiveSkillLevelLength(builder, AllyPassiveSkillLevelLength): builder.PrependInt32Slot(57, AllyPassiveSkillLevelLength, 0)


    @staticmethod
    def AddEnemyPassiveSkillIdLength(builder, EnemyPassiveSkillIdLength): builder.PrependInt32Slot(58, EnemyPassiveSkillIdLength, 0)


    @staticmethod
    def AddEnemyPassiveSkillLevelLength(builder, EnemyPassiveSkillLevelLength): builder.PrependInt32Slot(59, EnemyPassiveSkillLevelLength, 0)

