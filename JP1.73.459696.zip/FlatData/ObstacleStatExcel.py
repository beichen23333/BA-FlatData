
import flatbuffers
from flatbuffers.compat import import_numpy
np = import_numpy()

class ObstacleStatExcel:
    __slots__ = ['_tab']

    @classmethod
    def GetRootAs(cls, buf, offset=0):
        n = flatbuffers.encode.Get(flatbuffers.packer.uoffset, buf, offset)
        x = ObstacleStatExcel()
        x.Init(buf, n + offset)
        return x

    def Init(self, buf, pos):
        self._tab = flatbuffers.table.Table(buf, pos)


    def StringID(self):
        o = flatbuffers.number_types.UOffsetTFlags.py_type(self._tab.Offset(4))
        if o != 0:
            return self._tab.Get(flatbuffers.number_types.Uint32Flags, o + self._tab.Pos)
        return 0


    def Name(self):
        o = flatbuffers.number_types.UOffsetTFlags.py_type(self._tab.Offset(6))
        if o != 0:
            return self._tab.String(o + self._tab.Pos)
        return None


    def MaxHP1(self):
        o = flatbuffers.number_types.UOffsetTFlags.py_type(self._tab.Offset(8))
        if o != 0:
            return self._tab.Get(flatbuffers.number_types.Int32Flags, o + self._tab.Pos)
        return 0


    def MaxHP100(self):
        o = flatbuffers.number_types.UOffsetTFlags.py_type(self._tab.Offset(10))
        if o != 0:
            return self._tab.Get(flatbuffers.number_types.Int32Flags, o + self._tab.Pos)
        return 0


    def BlockRate(self):
        o = flatbuffers.number_types.UOffsetTFlags.py_type(self._tab.Offset(12))
        if o != 0:
            return self._tab.Get(flatbuffers.number_types.Int32Flags, o + self._tab.Pos)
        return 0


    def Dodge(self):
        o = flatbuffers.number_types.UOffsetTFlags.py_type(self._tab.Offset(14))
        if o != 0:
            return self._tab.Get(flatbuffers.number_types.Int32Flags, o + self._tab.Pos)
        return 0


    def CanNotStandRange(self):
        o = flatbuffers.number_types.UOffsetTFlags.py_type(self._tab.Offset(16))
        if o != 0:
            return self._tab.Get(flatbuffers.number_types.Int32Flags, o + self._tab.Pos)
        return 0


    def HighlightFloaterHeight(self):
        o = flatbuffers.number_types.UOffsetTFlags.py_type(self._tab.Offset(18))
        if o != 0:
            return self._tab.Get(flatbuffers.number_types.Float32Flags, o + self._tab.Pos)
        return 0


    def EnhanceLightArmorRate(self):
        o = flatbuffers.number_types.UOffsetTFlags.py_type(self._tab.Offset(20))
        if o != 0:
            return self._tab.Get(flatbuffers.number_types.Int32Flags, o + self._tab.Pos)
        return 0


    def EnhanceHeavyArmorRate(self):
        o = flatbuffers.number_types.UOffsetTFlags.py_type(self._tab.Offset(22))
        if o != 0:
            return self._tab.Get(flatbuffers.number_types.Int32Flags, o + self._tab.Pos)
        return 0


    def EnhanceUnarmedRate(self):
        o = flatbuffers.number_types.UOffsetTFlags.py_type(self._tab.Offset(24))
        if o != 0:
            return self._tab.Get(flatbuffers.number_types.Int32Flags, o + self._tab.Pos)
        return 0


    def EnhanceElasticArmorRate(self):
        o = flatbuffers.number_types.UOffsetTFlags.py_type(self._tab.Offset(26))
        if o != 0:
            return self._tab.Get(flatbuffers.number_types.Int32Flags, o + self._tab.Pos)
        return 0


    def EnhanceCompositeArmorRate(self):
        o = flatbuffers.number_types.UOffsetTFlags.py_type(self._tab.Offset(28))
        if o != 0:
            return self._tab.Get(flatbuffers.number_types.Int32Flags, o + self._tab.Pos)
        return 0


    def EnhanceStructureRate(self):
        o = flatbuffers.number_types.UOffsetTFlags.py_type(self._tab.Offset(30))
        if o != 0:
            return self._tab.Get(flatbuffers.number_types.Int32Flags, o + self._tab.Pos)
        return 0


    def EnhanceNormalArmorRate(self):
        o = flatbuffers.number_types.UOffsetTFlags.py_type(self._tab.Offset(32))
        if o != 0:
            return self._tab.Get(flatbuffers.number_types.Int32Flags, o + self._tab.Pos)
        return 0


    def ReduceExDamagedRate(self):
        o = flatbuffers.number_types.UOffsetTFlags.py_type(self._tab.Offset(34))
        if o != 0:
            return self._tab.Get(flatbuffers.number_types.Int32Flags, o + self._tab.Pos)
        return 0


    def ReduceBasicsDamagedRate(self):
        o = flatbuffers.number_types.UOffsetTFlags.py_type(self._tab.Offset(36))
        if o != 0:
            return self._tab.Get(flatbuffers.number_types.Int32Flags, o + self._tab.Pos)
        return 0


    def ReduceWeakDamagedRate(self):
        o = flatbuffers.number_types.UOffsetTFlags.py_type(self._tab.Offset(38))
        if o != 0:
            return self._tab.Get(flatbuffers.number_types.Int32Flags, o + self._tab.Pos)
        return 0


    def ReduceResistDamagedRate(self):
        o = flatbuffers.number_types.UOffsetTFlags.py_type(self._tab.Offset(40))
        if o != 0:
            return self._tab.Get(flatbuffers.number_types.Int32Flags, o + self._tab.Pos)
        return 0


    def AddSummonedObstacleDamagedRatio(self):
        o = flatbuffers.number_types.UOffsetTFlags.py_type(self._tab.Offset(42))
        if o != 0:
            return self._tab.Get(flatbuffers.number_types.Int32Flags, o + self._tab.Pos)
        return 0


    def DamagedRatioObstacle(self):
        o = flatbuffers.number_types.UOffsetTFlags.py_type(self._tab.Offset(44))
        if o != 0:
            return self._tab.Get(flatbuffers.number_types.Int32Flags, o + self._tab.Pos)
        return 0


    def WeakDamagedRatio(self):
        o = flatbuffers.number_types.UOffsetTFlags.py_type(self._tab.Offset(46))
        if o != 0:
            return self._tab.Get(flatbuffers.number_types.Int32Flags, o + self._tab.Pos)
        return 0


    def EffectiveDamagedRatio(self):
        o = flatbuffers.number_types.UOffsetTFlags.py_type(self._tab.Offset(48))
        if o != 0:
            return self._tab.Get(flatbuffers.number_types.Int32Flags, o + self._tab.Pos)
        return 0


    def NormalDamagedRatio(self):
        o = flatbuffers.number_types.UOffsetTFlags.py_type(self._tab.Offset(50))
        if o != 0:
            return self._tab.Get(flatbuffers.number_types.Int32Flags, o + self._tab.Pos)
        return 0


    def ResistDamagedRatio(self):
        o = flatbuffers.number_types.UOffsetTFlags.py_type(self._tab.Offset(52))
        if o != 0:
            return self._tab.Get(flatbuffers.number_types.Int32Flags, o + self._tab.Pos)
        return 0




    @staticmethod
    def Start(builder): builder.StartObject(25)
    @staticmethod
    def End(builder): return builder.EndObject()


    @staticmethod
    def AddStringID(builder, StringID): builder.PrependUint32Slot(0, StringID, 0)


    @staticmethod
    def AddName(builder, Name): builder.PrependUOffsetTRelativeSlot(1, flatbuffers.number_types.UOffsetTFlags.py_type(Name), 0)

    @staticmethod
    def AddMaxHP1(builder, MaxHP1): builder.PrependInt32Slot(2, MaxHP1, 0)


    @staticmethod
    def AddMaxHP100(builder, MaxHP100): builder.PrependInt32Slot(3, MaxHP100, 0)


    @staticmethod
    def AddBlockRate(builder, BlockRate): builder.PrependInt32Slot(4, BlockRate, 0)


    @staticmethod
    def AddDodge(builder, Dodge): builder.PrependInt32Slot(5, Dodge, 0)


    @staticmethod
    def AddCanNotStandRange(builder, CanNotStandRange): builder.PrependInt32Slot(6, CanNotStandRange, 0)


    @staticmethod
    def AddHighlightFloaterHeight(builder, HighlightFloaterHeight): builder.PrependFloat32Slot(7, HighlightFloaterHeight, 0)


    @staticmethod
    def AddEnhanceLightArmorRate(builder, EnhanceLightArmorRate): builder.PrependInt32Slot(8, EnhanceLightArmorRate, 0)


    @staticmethod
    def AddEnhanceHeavyArmorRate(builder, EnhanceHeavyArmorRate): builder.PrependInt32Slot(9, EnhanceHeavyArmorRate, 0)


    @staticmethod
    def AddEnhanceUnarmedRate(builder, EnhanceUnarmedRate): builder.PrependInt32Slot(10, EnhanceUnarmedRate, 0)


    @staticmethod
    def AddEnhanceElasticArmorRate(builder, EnhanceElasticArmorRate): builder.PrependInt32Slot(11, EnhanceElasticArmorRate, 0)


    @staticmethod
    def AddEnhanceCompositeArmorRate(builder, EnhanceCompositeArmorRate): builder.PrependInt32Slot(12, EnhanceCompositeArmorRate, 0)


    @staticmethod
    def AddEnhanceStructureRate(builder, EnhanceStructureRate): builder.PrependInt32Slot(13, EnhanceStructureRate, 0)


    @staticmethod
    def AddEnhanceNormalArmorRate(builder, EnhanceNormalArmorRate): builder.PrependInt32Slot(14, EnhanceNormalArmorRate, 0)


    @staticmethod
    def AddReduceExDamagedRate(builder, ReduceExDamagedRate): builder.PrependInt32Slot(15, ReduceExDamagedRate, 0)


    @staticmethod
    def AddReduceBasicsDamagedRate(builder, ReduceBasicsDamagedRate): builder.PrependInt32Slot(16, ReduceBasicsDamagedRate, 0)


    @staticmethod
    def AddReduceWeakDamagedRate(builder, ReduceWeakDamagedRate): builder.PrependInt32Slot(17, ReduceWeakDamagedRate, 0)


    @staticmethod
    def AddReduceResistDamagedRate(builder, ReduceResistDamagedRate): builder.PrependInt32Slot(18, ReduceResistDamagedRate, 0)


    @staticmethod
    def AddAddSummonedObstacleDamagedRatio(builder, AddSummonedObstacleDamagedRatio): builder.PrependInt32Slot(19, AddSummonedObstacleDamagedRatio, 0)


    @staticmethod
    def AddDamagedRatioObstacle(builder, DamagedRatioObstacle): builder.PrependInt32Slot(20, DamagedRatioObstacle, 0)


    @staticmethod
    def AddWeakDamagedRatio(builder, WeakDamagedRatio): builder.PrependInt32Slot(21, WeakDamagedRatio, 0)


    @staticmethod
    def AddEffectiveDamagedRatio(builder, EffectiveDamagedRatio): builder.PrependInt32Slot(22, EffectiveDamagedRatio, 0)


    @staticmethod
    def AddNormalDamagedRatio(builder, NormalDamagedRatio): builder.PrependInt32Slot(23, NormalDamagedRatio, 0)


    @staticmethod
    def AddResistDamagedRatio(builder, ResistDamagedRatio): builder.PrependInt32Slot(24, ResistDamagedRatio, 0)

